#include<iostream>
using namespace std;
int main(){
cout<<"halo from nacho's world"<<endl;
}
